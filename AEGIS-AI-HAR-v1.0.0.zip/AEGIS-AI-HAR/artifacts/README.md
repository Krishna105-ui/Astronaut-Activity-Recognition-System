Diagnostic and install reports land here.
