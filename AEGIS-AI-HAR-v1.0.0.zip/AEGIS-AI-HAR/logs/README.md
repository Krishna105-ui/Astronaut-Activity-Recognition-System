Session logs land here: <session>.log, .jsonl, _report.txt
