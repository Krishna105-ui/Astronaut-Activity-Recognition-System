Trained action model: action_model.onnx + .meta.json + MODEL_CARD.md (created by TRAIN_MODEL.bat)
