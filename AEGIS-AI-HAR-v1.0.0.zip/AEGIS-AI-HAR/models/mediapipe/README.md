MediaPipe .task bundles land here (FETCH_MODELS.bat). Only needed if your wheel lacks mp.solutions.
