Optional Tier-2 YOLO weights (best.pt) go here. See docs/TRAINING.md.
