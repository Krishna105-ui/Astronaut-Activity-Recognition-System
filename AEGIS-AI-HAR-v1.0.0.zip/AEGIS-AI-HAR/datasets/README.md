Recorded clips land in datasets/actions/clips/ as .npz feature sequences.
