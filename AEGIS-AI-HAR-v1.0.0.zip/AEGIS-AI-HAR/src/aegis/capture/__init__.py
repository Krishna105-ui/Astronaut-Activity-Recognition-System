"""AEGIS subpackage."""
